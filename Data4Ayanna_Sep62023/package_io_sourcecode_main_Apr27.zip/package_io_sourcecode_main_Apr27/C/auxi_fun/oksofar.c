#pragma once
#include <stdio.h>
int oksofar(char * msg){
printf("%s\n",msg);
fflush(stdout);
return 0;

}

