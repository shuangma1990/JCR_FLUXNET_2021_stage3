#pragma once
int filediag(FILE *pt,char *filename){

if (pt==0){printf("file %s not opened, expect error!\n", filename);}
return 0;
}
