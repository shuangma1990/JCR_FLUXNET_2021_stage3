#pragma once
#include "math.h"

int int_max(int a, int b) {
    if (a>b){b=a;}
	return b;
}
