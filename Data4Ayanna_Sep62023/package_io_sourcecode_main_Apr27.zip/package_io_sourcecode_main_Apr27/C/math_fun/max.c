#pragma once
double max(double a,double b){
if (a>b){b=a;}
return b;}
