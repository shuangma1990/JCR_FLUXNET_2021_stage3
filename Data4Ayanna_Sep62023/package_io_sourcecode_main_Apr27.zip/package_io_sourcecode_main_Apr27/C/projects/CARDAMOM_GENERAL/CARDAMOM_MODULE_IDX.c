#pragma once
typedef struct MODELS{
int dalec_1004;}MODELS;


typedef struct HYDROLOGY{
int infiltration_imax;
int van_genuchten;}HYDROLOGY;

typedef struct MODULE_IDX{
MODELS MODELS;
HYDROLOGY HYDROLOGY;}MODULE_IDX;

