CARDAMOM functions

(a) ALL CARDAMOM functions can run ALL models.
(b) Model choice is determined by DATA.ID
(c) Model properties, such as number of parameters, number of fluxes, pools, etc. are provided by CARDAMOM_MODEL_LIBRARY (based on valid DATA.ID).

