

FLUX_INFO.NAME[gpp]='Gross Primary productivity';
FLUX_INFO.ABBREVIATION[gpp]='GPP';
FLUX_INFO.UNITS[gpp]='gC/m2/day';

FLUX_INFO.NAME[resp_auto]='Gross Primary productivity';
FLUX_INFO.ABBREVIATION[resp_auto]='GPP';
FLUX_INFO.UNITS[resp_auto]='gC/m2/day';

...

...

 
