#pragma once


/*Van genuchten conversion*/
double van_genuchten(double *SM, double *b)
/*SOil moisture: mm/mm (or m3/m3)

PSI=



return PSI;}

