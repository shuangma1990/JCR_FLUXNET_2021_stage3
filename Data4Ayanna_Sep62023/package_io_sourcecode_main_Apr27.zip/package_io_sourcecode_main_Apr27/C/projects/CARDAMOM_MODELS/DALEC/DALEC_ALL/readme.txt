This folder contains functions that are used by multiple DALEC routines.

To maintain consistency, they are all kept in the same folder (i.e. here)
