int oksofar(char *msg){
printf("%s\n",msg);
fflush(stdout);
return 0;

}

